<?php
// Before removing this file, please verify the PHP ini setting `auto_prepend_file` does not point to this.

if (file_exists('F:\\xampp\\htdocs\\server5\\jeff\\wp-content\\plugins\\wordfence/waf/bootstrap.php')) {
	define("WFWAF_LOG_PATH", 'F:\\xampp\\htdocs\\server5\\jeff/wp-content/wflogs/');
	include_once 'F:\\xampp\\htdocs\\server5\\jeff\\wp-content\\plugins\\wordfence/waf/bootstrap.php';
}
?>